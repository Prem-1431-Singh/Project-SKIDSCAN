#!/usr/bin/env python3
"""
BlackMirror realtime dashboard
– Crawls a .onion URL through Tor
– Runs lightweight AI_Wayback analysis
– Shows both outputs in an easy-to-read UI
"""

import os, random, socket, subprocess, requests
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash

# ───────────── CONFIG ─────────────────────────
TOR_PROXY  = "socks5h://127.0.0.1:9050"
KEYWORDS   = ["login", "password", "email", "bitcoin", "admin", "secure"]
EXPORT_TXT = "exports/realtime_results.txt"
AI_EXPORT  = "exports/ai_results.txt"
# ───────────────────────────────────────────────

# ---------- helpers ---------------------------
def tor_up(port: int = 9050) -> bool:
    try:
        s = socket.create_connection(("127.0.0.1", port), timeout=3)
        s.close()
        return True
    except Exception:
        return False

def tor_get(url: str, timeout=20):
    hdr = {"User-Agent": f"BlackMirror/{random.randint(100,999)}"}
    prox = {"http": TOR_PROXY, "https": TOR_PROXY}
    return requests.get(url, headers=hdr, proxies=prox, timeout=timeout)

def crawl(url: str):
    try:
        r = tor_get(url)
        r.raise_for_status()
        hits = [kw for kw in KEYWORDS if kw in r.text.lower()]
        return hits, None
    except Exception as e:
        return None, f"Fetch error → {e}"

def run_ai_wayback(url: str):
    # always create exports folder
    os.makedirs(os.path.dirname(AI_EXPORT), exist_ok=True)
    try:
        proc = subprocess.run(
            ["python", "AI_Wayback.py", "-d", url,
             "-o", AI_EXPORT, "--format", "txt"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=120
        )
        # If script didn’t write anything, write stdout ourselves
        if not os.path.getsize(AI_EXPORT):
            with open(AI_EXPORT, "w") as f:
                f.write(proc.stdout or "[AI_Wayback returned no data]\n")
    except Exception as e:
        with open(AI_EXPORT, "w") as f:
            f.write(f"[AI_Wayback failed] {e}\n")

def parse_ai_line(raw: str):
    try:
        ts, url, kw_part, email_part, cred_part = raw.split(" | ")
        ts = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
        kw_list = kw_part.split(":[")[1].rstrip("]")
        emails  = email_part.split(":")[1]
        creds   = "Yes ✅" if cred_part.split(":")[1].strip().lower() == "yes" else "No ❌"
        return {"ts": ts.strftime("%b %d, %Y %H:%M"),
                "url": url, "keywords": kw_list or "None",
                "emails": emails, "creds": creds}
    except Exception:
        return {"error": raw}

# ---------- Flask -----------------------------
app = Flask(__name__)
app.secret_key = "blackmirror-dash"
os.makedirs("exports", exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        target = request.form.get("onion_url", "").strip()
        if not target.endswith(".onion"):
            flash("Please enter a .onion URL", "error")
            return redirect(url_for("index"))

        # Crawler
        hits, err = crawl(target)
        if err:
            flash(err, "error")
        else:
            with open(EXPORT_TXT, "a") as f:
                f.write(f"{target} -> {hits}\n")
            flash(f"Crawl done – {len(hits)} keywords found", "success")

        # AI Wayback
        run_ai_wayback(target)
        return redirect(url_for("index"))

    # Load results
    real = open(EXPORT_TXT).read().splitlines() if os.path.exists(EXPORT_TXT) else []
    ai_raw = open(AI_EXPORT).read().splitlines() if os.path.exists(AI_EXPORT) else []
    ai_fmt = [parse_ai_line(l) for l in ai_raw]

    return render_template("index.html",
                           realtime_results=real,
                           ai_results=ai_fmt)

# ---------- main ------------------------------
if __name__ == "__main__":
    if not tor_up():
        print("[!] Tor not running on 9050.  Start Tor and retry.")
        exit(1)
    print("Dashboard → http://127.0.0.1:5000")
    app.run(port=5000, debug=False)

