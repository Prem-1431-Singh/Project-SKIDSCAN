import os
import requests
from urllib.parse import urlparse

PROXIES = {
    'http': 'socks5h://127.0.0.1:9050',
    'https': 'socks5h://127.0.0.1:9050',
}

KEYWORDS = ["login", "password", "email", "bitcoin", "wallet", "secure", "admin"]

def ensure_dirs():
    os.makedirs("exports", exist_ok=True)
    os.makedirs("config", exist_ok=True)

def load_sites():
    path = "config/sites.txt"
    if not os.path.exists(path):
        print("[!] config/sites.txt not found.")
        return []
    with open(path, "r") as f:
        return [line.strip() for line in f if line.strip()]

def crawl():
    ensure_dirs()
    sites = load_sites()
    if not sites:
        print("[!] No sites to crawl.")
        return

    results = []
    for url in sites:
        print(f"[+] Crawling: {url}")
        try:
            r = requests.get(url, proxies=PROXIES, timeout=30)
            content = r.text.lower()
            found = [kw for kw in KEYWORDS if kw in content]
            if found:
                print(f"[✔] MATCH @ {url} → {len(found)} terms → {found}")
                results.append((url, found))
        except Exception as e:
            print(f"[✖] Failed: {url} → {e}")

    with open("exports/results.txt", "w") as f:
        for url, keys in results:
            f.write(f"{url} → {keys}\n")
    print(f"[✓] Done. Saved results to exports/results.txt")

if __name__ == "__main__":
    crawl()
