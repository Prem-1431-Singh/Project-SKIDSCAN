#!/usr/bin/env python3
import requests
import time
from stem import Signal
from stem.control import Controller

TOR_PROXY = 'socks5h://127.0.0.1:9050'
session = requests.Session()
session.proxies = {'http': TOR_PROXY, 'https': TOR_PROXY}

def check_site(url):
    try:
        r = session.get(url, timeout=15)
        return r.status_code == 200
    except Exception:
        return False

def load_sites(file_path):
    with open(file_path, 'r') as f:
        return [line.strip() for line in f if line.strip()]

def save_alive(sites, out_path):
    with open(out_path, 'w') as f:
        for s in sites:
            f.write(s + '\n')

if __name__ == "__main__":
    sites = load_sites('config/sites.txt')
    alive = []

    print("[*] Checking .onion site health over Tor...")
    for site in sites:
        print(f"[+] Checking {site}...", end=" ")
        if check_site(site):
            print("✅ Alive")
            alive.append(site)
        else:
            print("❌ Dead")

    save_alive(alive, 'config/sites_alive.txt')
    print(f"[✓] Done. {len(alive)}/{len(sites)} alive sites saved to config/sites_alive.txt")
