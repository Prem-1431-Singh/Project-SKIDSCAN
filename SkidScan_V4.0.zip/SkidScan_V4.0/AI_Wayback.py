#!/usr/bin/env python3
"""
Super-light AI_Wayback substitute
— fetches a single URL, scans for basic indicators,
  writes one summary line to exports/ai_results.txt
Usage:
    python AI_Wayback.py -d <URL> -o exports/ai_results.txt
"""

import argparse, os, re, sys, time, random
from datetime import datetime

try:
    import requests          # pip install requests[socks]
except ImportError:
    print("requests not installed.  Run:  pip install requests[socks]")
    sys.exit(1)

# ---------- simple helpers ----------------------------------------------------
UAGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (X11; Linux x86_64)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
]

KEYWORDS  = ["password", "login", "admin", "secret", "token", "bitcoin", "email"]
CRED_RGX  = re.compile(r"(?i)(password[^\\n]{0,40})|(api[_-]?key[^\\n]{0,40})")
EMAIL_RGX = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")

def fetch(url: str, timeout=20) -> str | None:
    """Fetch URL via clearnet or Tor (.onion)."""
    headers = {"User-Agent": random.choice(UAGENTS)}
    proxies = {"http": "socks5h://127.0.0.1:9050",
               "https": "socks5h://127.0.0.1:9050"} if ".onion" in url else None
    try:
        r = requests.get(url, timeout=timeout, headers=headers, proxies=proxies)
        if r.status_code == 200 and len(r.text) > 20:
            return r.text
    except Exception as e:
        return f"FETCH_ERROR: {e}"
    return "FETCH_FAILED"

def analyse(text: str) -> dict:
    """Quick heuristics: keyword hits, emails, possible creds."""
    out = {"keywords": [], "email_cnt": 0, "cred_hit": False}
    if text.startswith("FETCH_"):
        out["error"] = text
        return out
    lower = text.lower()
    out["keywords"] = [kw for kw in KEYWORDS if kw in lower]
    out["email_cnt"] = len(EMAIL_RGX.findall(text))
    out["cred_hit"]  = bool(CRED_RGX.search(text))
    return out

# ---------- main --------------------------------------------------------------
def main():
    p = argparse.ArgumentParser()
    p.add_argument("-d", "--domain", required=True, help="URL or domain to analyse")
    p.add_argument("-o", "--output", default="exports/ai_results.txt")
    args, _ = p.parse_known_args()

    url = args.domain if args.domain.startswith(("http://", "https://")) \
          else f"http://{args.domain}"
    raw = fetch(url)
    result = analyse(raw)

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if "error" in result:
        line = f"{stamp} | {url} | ERROR | {result['error']}"
    else:
        kws = ",".join(result["keywords"]) or "none"
        cred = "YES" if result["cred_hit"] else "no"
        line = (f"{stamp} | {url} | kw:[{kws}] | "
                f"emails:{result['email_cnt']} | creds:{cred}")

    with open(args.output, "a") as f:
        f.write(line + "\n")

    print(line)                 # stdout (Flask captures if needed)


if __name__ == "__main__":
    main()

